#ifdef __cplusplus
extern "C" {
#endif
#include <sys/termios.h>
#ifdef __cplusplus
}
#endif
